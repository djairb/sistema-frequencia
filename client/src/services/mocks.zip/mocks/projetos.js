export const mockProjetos = [
  {
    "id": 1,
    "titulo": "Conecta Vidas",
    "descricao": "Projeto de integração social e capacitação em saúde.",
    "data_inicio": "2026-01-01T00:00:00.000Z",
    "data_final_prevista": "2026-12-31T00:00:00.000Z",
    "status": "ativo"
  },
  {
    "id": 2,
    "titulo": "VamoSimbora",
    "descricao": "Iniciativa de aceleração profissional técnica.",
    "data_inicio": "2026-02-01T00:00:00.000Z",
    "data_final_prevista": "2027-01-30T00:00:00.000Z",
    "status": "ativo"
  }
];